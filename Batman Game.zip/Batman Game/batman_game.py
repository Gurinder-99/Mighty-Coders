import pygame
import random

# Firstly, let's initialize pygame.
pygame.init()

# Initializing the mixer for audio playback.
pygame.mixer.init()

# Applying background music to the game.
pygame.mixer.music.load('batmanaudio.mp3')
pygame.mixer.music.set_volume(0.5)
pygame.mixer.music.play(-1)

# Screen dimensions.
width, height = 800, 600
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Batman Game")

# Defining the colors.
black = (0, 0, 0)
white = (255, 255, 255)
red = (255, 0, 0)
green = (0, 255, 0)
darkgreen = (1, 50, 32)

# Setting the FPS to 60 for smooth gameplay.
FPS = 60
clock = pygame.time.Clock()

# Loading the character images.
hero = pygame.image.load('batman.png')
enemy = pygame.image.load('joker.png')
boss_joker = pygame.image.load('boss.png')
background = pygame.image.load('background.png')
healthboost = pygame.image.load('healthboost.png')

# Player class.
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.transform.scale(hero, (50, 50))
        self.rect = self.image.get_rect()
        self.rect.center = (100, height // 2)
        self.speed = 5
        self.health = 100
        self.max_health = 100
        self.lives = 3

# Defining the keys for character movements.
    def update(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] and self.rect.right < width:
            self.rect.x += self.speed
        if keys[pygame.K_UP] and self.rect.top > 0:
            self.rect.y -= self.speed
        if keys[pygame.K_DOWN] and self.rect.bottom < height:
            self.rect.y += self.speed

    def draw_health_bar(self):
        health_ratio = self.health / self.max_health
        pygame.draw.rect(screen, red, (20, 20, 200, 20))
        pygame.draw.rect(screen, green, (20, 20, 200 * health_ratio, 20))

# Enemy class.
class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.transform.scale(enemy, (50, 50))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed = random.randint(2, 5)

    def update(self):
        self.rect.x -= self.speed
        if self.rect.right < 0:
            self.kill()

# Boss Projectile class.
class BossProjectile(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((10, 5))
        self.image.fill(darkgreen)
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.speed = 7

    def update(self):
        self.rect.x -= self.speed
        if self.rect.right < 0:
            self.kill()

# Boss enemy class.
class Boss(Enemy):
    def __init__(self, x, y):
        super().__init__(x, y)
        self.image = pygame.transform.scale(boss_joker, (100, 100))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed = 4
        self.health = 500
        self.shoot_delay = 1000
        self.last_shot = pygame.time.get_ticks()

    def update(self):
        self.rect.x -= self.speed
        if self.rect.right < 0:
            self.kill()

        # Boss shooting logic
        now = pygame.time.get_ticks()
        if now - self.last_shot > self.shoot_delay:
            self.last_shot = now
            boss_bullet = BossProjectile(self.rect.left, self.rect.centery)
            boss_projectiles.add(boss_bullet)

    def draw_health_bar(self):
        health_ratio = self.health / 400
        pygame.draw.rect(screen, red, (self.rect.x, self.rect.y - 10, 100, 10))
        pygame.draw.rect(screen, green, (self.rect.x, self.rect.y - 10, 100 * health_ratio, 10))

# HealthBoost class.
class HealthBoost(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.transform.scale(healthboost, (30, 30))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

    def update(self):
        self.rect.x -= 3
        if self.rect.right < 0:
            self.kill()

# Player Projectile class.
class Projectile(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((10, 5))
        self.image.fill(black)
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.speed = 10

    def update(self):
        self.rect.x += self.speed
        if self.rect.left > width:
            self.kill()

# Game over and restart.
def game_over_screen(message):
    font = pygame.font.SysFont(None, 55)
    text = font.render(message, True, black)
    text_rect = text.get_rect(center=(width // 2, height // 2))
    screen.fill(white)
    screen.blit(text, text_rect)
    pygame.display.flip()

    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    return True

# Reset the game after it's over.
def reset_game():
    global player, enemies, boss, projectiles, boss_projectiles, health_boosts, level, score
    player = Player()
    enemies = pygame.sprite.Group()
    boss = pygame.sprite.Group()
    projectiles = pygame.sprite.Group()
    boss_projectiles = pygame.sprite.Group()
    health_boosts = pygame.sprite.Group()
    level = 1
    score = 0
    create_enemies(level)

# Increasing the number of enemies with each level.
def create_enemies(level):
    if level < 3:
        for i in range(5 + level):
            enemy = Enemy(width + random.randint(50, 300), random.randint(100, height - 100))
            enemies.add(enemy)
    else:
        boss_enemy = Boss(width + random.randint(100, 300), random.randint(100, height - 150))
        boss.add(boss_enemy)

# main_game() function.
def main_game():
    global running
    running = True
    while running:
        clock.tick(FPS)

        # Checking for events.
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_f:
                    projectile = Projectile(player.rect.right, player.rect.centery)
                    projectiles.add(projectile)

        # Updating the hero, enemies, boss, projectiles, and health boosts.
        player.update()
        enemies.update()
        boss.update()
        projectiles.update()
        boss_projectiles.update()
        health_boosts.update()

        # Checking for collisions between projectiles and enemies.
        for projectile in projectiles:
            enemy_hit_list = pygame.sprite.spritecollide(projectile, enemies, True)
            for enemy in enemy_hit_list:
                projectile.kill()
                global score
                score += 10

        # Checking for collisions between projectiles and boss.
        for projectile in projectiles:
            boss_hit_list = pygame.sprite.spritecollide(projectile, boss, False)
            for boss_enemy in boss_hit_list:
                boss_enemy.health -= 10
                if boss_enemy.health <= 0:
                    boss_enemy.kill()
                    return "You won! Press R to restart"

        # Checking for collisions between hero and enemies.
        enemy_collision_list = pygame.sprite.spritecollide(player, enemies, False)
        if enemy_collision_list:
            player.health -= 10
            if player.health <= 0:
                player.lives -= 1
                player.health = player.max_health
                if player.lives <= 0:
                    running = False

        # Checking for collisions between hero and boss projectiles.
        boss_bullet_hit_list = pygame.sprite.spritecollide(player, boss_projectiles, True)
        for boss_bullet in boss_bullet_hit_list:
            player.health -= 15  #
            if player.health <= 0:
                player.lives -= 1
                player.health = player.max_health
                if player.lives <= 0:
                    running = False

        # Checking for collisions between hero and boss.
        boss_collision_list = pygame.sprite.spritecollide(player, boss, False)
        if boss_collision_list:
            player.health -= 20
            if player.health <= 0:
                player.lives -= 1
                player.health = player.max_health
                if player.lives <= 0:
                    running = False

        # Checking for collisions between player and health boosts.
        boost_collision_list = pygame.sprite.spritecollide(player, health_boosts, True)
        for boost in boost_collision_list:
            player.health += 20
            if player.health > player.max_health:
                player.health = player.max_health

        # Capping the game to level 3.
        if len(enemies) == 0 and len(boss) == 0:
            global level
            if level < 3:
                level += 1
                create_enemies(level)
            else:
                return "Game Over! Press R to restart"

        # Randomly spawning health boosts.
        if random.random() < 0.01:
            health_boost = HealthBoost(width + 100, random.randint(100, height - 100))
            health_boosts.add(health_boost)

        # Drawing everything on game screen.
        screen.fill(white)
        screen.blit(background, (0, 0))
        screen.blit(player.image, player.rect)
        enemies.draw(screen)
        boss.draw(screen)
        projectiles.draw(screen)
        boss_projectiles.draw(screen)
        health_boosts.draw(screen)

        # Drawing health bar and score.
        player.draw_health_bar()
        for boss_enemy in boss:
            boss_enemy.draw_health_bar()

        # Displaying the level.
        font = pygame.font.SysFont(None, 36)
        level_text = font.render(f"Level {level}", True, black)
        screen.blit(level_text, (width // 2 - level_text.get_width() // 2, 10))

        # Displaying the score.
        score_text = font.render(f"Score: {score}", True, black)
        screen.blit(score_text, (width - 150, 20))

        # Update the display
        pygame.display.flip()

reset_game()

while True:
    message = main_game()
    if message == "You won! Press R to restart":
        if not game_over_screen(message):
            break
    else:
        if not game_over_screen("Game Over! Press R to Restart"):
            break
    reset_game()

pygame.quit()
